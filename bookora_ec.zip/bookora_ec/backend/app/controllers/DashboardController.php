<?php

require_once '../app/core/Controller.php';
require_once '../app/core/Database.php';

class DashboardController extends Controller
{

    private $db;

    public function __construct()
    {
        $this->db = (new Database())->connect();
    }

    public function stats()
    {

        $citas =
            $this->db->query(
                "SELECT COUNT(*) total FROM citas"
            )->fetch(PDO::FETCH_ASSOC);

        $usuarios =
            $this->db->query(
                "SELECT COUNT(*) total FROM usuarios"
            )->fetch(PDO::FETCH_ASSOC);

        $servicios =
            $this->db->query(
                "SELECT COUNT(*) total FROM servicios"
            )->fetch(PDO::FETCH_ASSOC);

        echo json_encode([

            "citas" =>
                $citas['total'],

            "usuarios" =>
                $usuarios['total'],

            "servicios" =>
                $servicios['total']
        ]);
    }
}