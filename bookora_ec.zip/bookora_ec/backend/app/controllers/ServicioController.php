<?php
require_once '../app/core/Controller.php';
require_once '../app/models/Servicio.php';

class ServicioController extends Controller
{
    public function index()
    {
        $this->json(
            (new Servicio())->all()
        );
    }

    public function create()
    {
        $nombre = $_POST['nombre'];
        $descripcion = $_POST['descripcion'];
        $duracion = $_POST['duracion'];
        $precio = $_POST['precio'];

        $imagen = null;

        if (isset($_FILES['imagen'])) {
            $archivo = time() . '_' .
                $_FILES['imagen']['name'];

            move_uploaded_file(
                $_FILES['imagen']['tmp_name'],
                '../public/uploads/' . $archivo
            );

            $imagen = $archivo;
        }

        $servicio = new Servicio();

        $servicio->create([
            'nombre' => $nombre,
            'descripcion' => $descripcion,
            'duracion' => $duracion,
            'precio' => $precio,
            'imagen' => $imagen
        ]);

        $this->json([
            'mensaje' => 'Servicio creado'
        ]);
    }

    public function delete()
    {
        $data = json_decode(
            file_get_contents("php://input"),
            true
        );

        (new Servicio())->delete(
            $data['servicio_id']
        );

        $this->json([
            'mensaje' => 'Servicio eliminado'
        ]);
    }
}