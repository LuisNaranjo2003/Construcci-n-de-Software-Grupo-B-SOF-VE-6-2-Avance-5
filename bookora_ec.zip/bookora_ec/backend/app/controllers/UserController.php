<?php

require_once '../app/core/Controller.php';
require_once '../app/models/User.php';

class UserController extends Controller
{
    // LISTAR

    public function index()
    {
        $usuarios = (new User())->getAll();

        $this->json($usuarios);
    }

    // ELIMINAR

    public function delete($id)
    {
        (new User())->delete($id);

        $this->json([
            "mensaje" => "Usuario eliminado"
        ]);
    }
}