<?php
class AuthMiddleware
{
    public static function verificar()
    {
        if (!isset($_GET['token'])) {
            echo json_encode(["error" => "No autorizado"]);
            exit;
        }
    }
}