<?php
require_once '../app/core/Database.php';

class Cita
{
    private $db;

    public function __construct()
    {
        $this->db = (new Database())->connect();
    }

    public function all()
    {
        return $this->db->query("SELECT * FROM citas")
            ->fetchAll(PDO::FETCH_ASSOC);
    }

    public function create($data)
    {
        $stmt = $this->db->prepare(
            "INSERT INTO citas(usuario_id,servicio_id,fecha,hora)
             VALUES(?,?,?,?)"
        );

        return $stmt->execute([
            $data->usuario_id,
            $data->servicio_id,
            $data->fecha,
            $data->hora
        ]);
    }

    public function existeCita($fecha, $hora)
    {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) FROM citas WHERE fecha=? AND hora=?"
        );

        $stmt->execute([$fecha, $hora]);

        return $stmt->fetchColumn() > 0;
    }

    public function verificarHorario($fecha, $hora)
    {
        $sql = "SELECT * FROM citas
                WHERE fecha = ?
                AND hora = ?
                AND estado != 'cancelada'";

        $stmt = $this->db->prepare($sql);

        $stmt->execute([$fecha, $hora]);

        return $stmt->fetch();
    }

    public function cancelar($id)
    {
        $sql = "UPDATE citas
                SET estado='cancelada'
                WHERE cita_id=?";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([$id]);
    }
}