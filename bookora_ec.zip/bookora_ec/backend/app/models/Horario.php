<?php
require_once '../app/core/Database.php';

class Horario
{
    private $db;

    public function __construct()
    {
        $this->db = (new Database())->connect();
    }

    public function verificar($dia, $hora)
    {
        $stmt = $this->db->prepare(
            "SELECT * FROM horarios 
             WHERE dia_semana=? 
             AND hora_inicio <= ? 
             AND hora_fin >= ?"
        );

        $stmt->execute([$dia, $hora, $hora]);

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}