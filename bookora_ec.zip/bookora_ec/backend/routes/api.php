<?php

require_once '../app/controllers/AuthController.php';
require_once '../app/controllers/CitaController.php';
require_once '../app/controllers/ServicioController.php';
require_once '../app/controllers/DashboardController.php';
require_once '../app/controllers/UserController.php';

$url = $_GET['url'] ?? '';

switch ($url) {

    // LOGIN
    case 'login':
        (new AuthController())->login();
        break;

    // REGISTER
    case 'register':
        (new AuthController())->register();
        break;

    // CITAS
    case 'citas':

        if ($_SERVER['REQUEST_METHOD'] === 'GET') {

            (new CitaController())->index();

        } else {

            (new CitaController())->store();
        }

        break;

    // CANCELAR CITA
    case 'cancelar-cita':

        (new CitaController())->cancelar();

        break;

    // SERVICIOS
    case 'servicios':

        (new ServicioController())->index();

        break;

    // DASHBOARD
    case 'dashboard/stats':

        (new DashboardController())->stats();

        break;

    // USUARIOS
    case 'usuarios':

        if ($_SERVER['REQUEST_METHOD'] === 'GET') {

            (new UserController())->index();

        }

        break;

    // ERROR
    default:

        echo json_encode([
            "error" => "Ruta no encontrada"
        ]);
}