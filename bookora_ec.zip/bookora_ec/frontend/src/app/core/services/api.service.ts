import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class ApiService {

    private API = 'http://localhost/bookora_ec/backend/public/?url=';

    constructor(private http: HttpClient) { }

    // =====================
    // LOGIN / REGISTER
    // =====================
    login(data: any) {
        return this.http.post(this.API + 'login', data);
    }

    register(data: any) {
        return this.http.post(this.API + 'register', data);
    }

    // =====================
    // CITAS
    // =====================
    getCitas() {
        return this.http.get(this.API + 'citas');
    }

    crearCita(data: any) {
        return this.http.post(this.API + 'citas', data);
    }

    cancelarCita(data: any) {
        return this.http.post(this.API + 'cancelar-cita', data);
    }

    // =====================
    // SERVICIOS
    // =====================
    getServicios() {
        return this.http.get(this.API + 'servicios');
    }

    crearServicio(data: FormData) {
        return this.http.post(this.API + 'servicios/create', data);
    }

    eliminarServicio(id: number) {
        return this.http.post(this.API + 'servicios/delete', { servicio_id: id });
    }

    // =====================
    // DASHBOARD
    // =====================
    obtenerDashboard() {
        return this.http.get(this.API + 'dashboard');
    }

    // =====================
    // ADMIN USUARIOS
    // =====================
    getUsuarios() {
        return this.http.get(this.API + 'usuarios');
    }

    crearUsuario(data: any) {
        return this.http.post(this.API + 'usuarios', data);
    }

    eliminarUsuario(id: number) {
        return this.http.post(this.API + 'eliminar-usuario', { usuario_id: id });
    }
}