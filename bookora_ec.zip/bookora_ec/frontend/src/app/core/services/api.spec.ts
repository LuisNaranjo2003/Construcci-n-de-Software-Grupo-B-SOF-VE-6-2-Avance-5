import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  private API = 'http://localhost/bookora_ec/backend/public/?url=';

  constructor(private http: HttpClient) { }

  login(data: any) {
    return this.http.post(this.API + 'login', data);
  }

  register(data: any) {
    return this.http.post(this.API + 'register', data);
  }

  obtenerCitas() {
    return this.http.get(this.API + 'citas');
  }

  crearCita(data: any) {
    return this.http.post(this.API + 'citas', data);
  }
}