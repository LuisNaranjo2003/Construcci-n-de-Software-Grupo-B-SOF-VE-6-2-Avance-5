import { Component, OnInit } from '@angular/core';

import { CommonModule } from '@angular/common';

import { SidebarAdminComponent }
  from '../../../shared/sidebar-admin/sidebar-admin';

import { ApiService }
  from '../../../core/services/api.service';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,

  imports: [
    CommonModule,
    SidebarAdminComponent
  ],

  templateUrl: './admin-dashboard.html',

  styleUrls: ['./admin-dashboard.css']
})

export class AdminDashboardComponent
  implements OnInit {

  totalCitas = 0;

  totalClientes = 0;

  totalServicios = 0;

  constructor(
    private api: ApiService
  ) { }

  ngOnInit(): void {

    this.api.obtenerDashboard()
      .subscribe((res: any) => {

        console.log(res);

        this.totalCitas =
          res.citas || 0;

        this.totalClientes =
          res.clientes || 0;

        this.totalServicios =
          res.servicios || 0;

      });
  }
}