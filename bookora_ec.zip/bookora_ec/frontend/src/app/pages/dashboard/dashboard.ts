import {
  Component,
  OnInit,
  ChangeDetectorRef
} from '@angular/core';

import { SidebarComponent } from '../../shared/sidebar/sidebar';
import { ApiService } from '../../core/services/api.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [SidebarComponent],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css'
})
export class DashboardComponent implements OnInit {

  user: any = JSON.parse(
    localStorage.getItem('user')!
  );

  hora: string = '';

  totalCitas: number = 0;
  totalClientes: number = 0;
  totalServicios: number = 0;

  constructor(
    private api: ApiService,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit(): void {

    this.actualizarHora();

    setInterval(() => {

      this.actualizarHora();

      this.cdr.detectChanges();

    }, 1000);

    this.obtenerDatos();
  }

  actualizarHora() {

    const fecha = new Date();

    this.hora = fecha.toLocaleTimeString(
      'es-EC',
      {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      }
    );
  }

  obtenerDatos() {

    this.api.obtenerDashboard()
      .subscribe((res: any) => {

        this.totalCitas = res.citas || 0;

        this.totalClientes =
          this.user ? 1 : 0;

        this.totalServicios =
          res.servicios || 0;

      });
  }
}