import { Component } from '@angular/core';

import { SidebarComponent } from '../../shared/sidebar/sidebar';

@Component({
  selector: 'app-integrantes',
  standalone: true,
  imports: [SidebarComponent],
  templateUrl: './integrantes.html',
  styleUrl: './integrantes.css'
})
export class IntegrantesComponent {

}