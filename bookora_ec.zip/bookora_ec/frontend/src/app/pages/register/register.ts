import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { NgIf } from '@angular/common';
import Swal from 'sweetalert2';
import { ApiService } from '../../core/services/api.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [
    FormsModule,
    RouterLink
  ],
  templateUrl: './register.html',
  styleUrl: './register.css'
})
export class RegisterComponent {
  nombre = '';
  email = '';
  password = '';
  rol_id = 2; // por defecto cliente
  mensaje = '';

  constructor(private api: ApiService, private router: Router) { }

  register() {
    if (!this.nombre || !this.email || !this.password) {
      Swal.fire({
        icon: 'warning',
        title: 'Campos incompletos',
        text: 'Complete todos los campos',
        background: '#0f172a',
        color: '#fff',
        confirmButtonColor: '#ec4899'
      });
      return;
    }

    this.api.register({
      nombre: this.nombre,
      email: this.email,
      password: this.password,
      rol_id: this.rol_id
    }).subscribe((res: any) => {
      if (res.mensaje) {
        Swal.fire({
          icon: 'success',
          title: 'Cuenta creada',
          text: 'Usuario registrado correctamente',
          background: '#0f172a',
          color: '#fff',
          confirmButtonColor: '#ec4899'
        });
        setTimeout(() => this.router.navigate(['/']), 1500);
      } else {
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: res.error,
          background: '#0f172a',
          color: '#fff',
          confirmButtonColor: '#ec4899'
        });
      }
    });
  }
}